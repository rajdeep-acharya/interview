package com.demo.entities;

public class SlotTiming implements Slot{

}
