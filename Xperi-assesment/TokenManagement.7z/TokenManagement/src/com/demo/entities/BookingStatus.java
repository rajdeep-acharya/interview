package com.demo.entities;

public enum BookingStatus {
    SUCCESSFUL ,
    PENDING ,
    FAIL;
}
