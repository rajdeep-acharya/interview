/*
package com.demo.entities;


public class RestApplication extends Application {

}
*/
